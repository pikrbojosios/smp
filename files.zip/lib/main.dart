import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(SMPN1BojonegaraApp());
}

class SMPN1BojonegaraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SMPN 1 Bojonegara',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Montserrat',
        brightness: Brightness.light,
      ),
      home: LoginScreen(),
    );
  }
}