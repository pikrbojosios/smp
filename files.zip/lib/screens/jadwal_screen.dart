import 'package:flutter/material.dart';

class JadwalScreen extends StatelessWidget {
  final List<Map<String, String>> jadwal = [
    {'hari': 'Senin', 'pelajaran': 'Matematika, Bahasa Indonesia'},
    {'hari': 'Selasa', 'pelajaran': 'IPA, IPS'},
    {'hari': 'Rabu', 'pelajaran': 'Bahasa Inggris, PJOK'},
    {'hari': 'Kamis', 'pelajaran': 'Seni Budaya, Agama'},
    {'hari': 'Jumat', 'pelajaran': 'Prakarya, PPKN'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Jadwal Pelajaran')),
      body: ListView.builder(
        itemCount: jadwal.length,
        itemBuilder: (context, i) => ListTile(
          leading: Icon(Icons.schedule, color: Colors.blue),
          title: Text(jadwal[i]['hari']!),
          subtitle: Text(jadwal[i]['pelajaran']!),
        ),
      ),
    );
  }
}