import 'package:flutter/material.dart';

class ProfilScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profil Sekolah')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: AssetImage('assets/logo.png'),
            ),
            SizedBox(height: 20),
            Text(
              'SMPN 1 Bojonegara',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Jl. Pendidikan No. 1, Bojonegara, Serang, Banten\nTelp: (021) 1234567',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 28),
            Text(
              'Sekolah Menengah Pertama Negeri 1 Bojonegara adalah sekolah yang berkomitmen pada pendidikan berkualitas dan karakter. Kami menyediakan lingkungan belajar yang nyaman dan modern.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}