import 'package:flutter/material.dart';

class PengumumanScreen extends StatelessWidget {
  final List<Map<String, String>> pengumuman = [
    {'judul': 'Libur Semester', 'isi': 'Libur semester dimulai tanggal 1 Juli 2025.'},
    {'judul': 'PPDB 2025', 'isi': 'Pendaftaran Peserta Didik Baru dibuka mulai 10 Juli 2025.'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pengumuman')),
      body: ListView.builder(
        itemCount: pengumuman.length,
        itemBuilder: (context, i) => ListTile(
          leading: Icon(Icons.announcement, color: Colors.orange),
          title: Text(pengumuman[i]['judul']!),
          subtitle: Text(pengumuman[i]['isi']!),
        ),
      ),
    );
  }
}