# SMPN 1 Bojonegara School App

Aplikasi sekolah elegan untuk SMPN 1 Bojonegara.

## Fitur:
- Login Siswa/Guru
- Pengumuman Sekolah
- Jadwal Pelajaran
- Profil Sekolah

## Cara Build APK
1. Pastikan sudah install [Flutter](https://flutter.dev/)
2. Clone repo ini
3. Jalankan `flutter pub get`
4. Jalankan `flutter build apk`